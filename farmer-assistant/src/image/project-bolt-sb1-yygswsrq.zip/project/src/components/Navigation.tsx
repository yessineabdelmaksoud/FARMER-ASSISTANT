import React from 'react';
import { Menu, Home, Leaf, CloudRain, BarChart2, FileSpreadsheet, AlertTriangle, Users } from 'lucide-react';

export function Navigation() {
  const navItems = [
    { icon: Home, label: 'Dashboard', href: '/' },
    { icon: Leaf, label: 'Plant Diagnosis', href: '/diagnosis' },
    { icon: CloudRain, label: 'Irrigation', href: '/irrigation' },
    { icon: BarChart2, label: 'Market Prices', href: '/market' },
    { icon: FileSpreadsheet, label: 'Soil Analysis', href: '/soil' },
    { icon: AlertTriangle, label: 'Weather Alerts', href: '/weather' },
  ];

  return (
    <nav className="bg-green-800 text-white h-screen w-64 fixed left-0 top-0 p-4">
      <div className="flex items-center gap-2 mb-8">
        <Leaf className="w-8 h-8" />
        <h1 className="text-xl font-bold">FarmAI Assistant</h1>
      </div>
      
      <ul className="space-y-2">
        {navItems.map((item) => (
          <li key={item.href}>
            <a
              href={item.href}
              className="flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}