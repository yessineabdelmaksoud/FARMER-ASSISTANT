export interface CropPlan {
  fieldSize: number;
  soilType: string;
  previousCrops: string[];
  goals: string[];
  resources: {
    water: boolean;
    labor: boolean;
    equipment: string[];
  };
}

export interface WeatherAlert {
  type: string;
  severity: 'low' | 'medium' | 'high';
  message: string;
  date: string;
}

export interface SoilAnalysis {
  composition: {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
    ph: number;
  };
  recommendations: string[];
  suitableCrops: string[];
}